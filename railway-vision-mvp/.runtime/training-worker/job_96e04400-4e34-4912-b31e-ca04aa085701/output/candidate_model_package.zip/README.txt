Vistral model package
- manifest.json: model metadata and hash
- model.enc: encrypted model bytes
- signature.sig: RSA signature for manifest+model.enc
