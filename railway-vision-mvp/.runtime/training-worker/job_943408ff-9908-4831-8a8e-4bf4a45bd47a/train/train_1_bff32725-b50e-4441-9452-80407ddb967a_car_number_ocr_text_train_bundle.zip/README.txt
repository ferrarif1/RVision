Vistral local car-number text dataset bundle
split=train
samples=44
images/ contains cropped number regions
annotations/records.jsonl contains OCR text labels
