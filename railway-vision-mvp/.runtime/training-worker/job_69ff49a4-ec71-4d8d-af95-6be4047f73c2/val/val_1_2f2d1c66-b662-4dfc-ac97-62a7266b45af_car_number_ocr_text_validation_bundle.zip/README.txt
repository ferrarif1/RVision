Vistral local car-number text dataset bundle
split=validation
samples=11
images/ contains cropped number regions
annotations/records.jsonl contains OCR text labels
