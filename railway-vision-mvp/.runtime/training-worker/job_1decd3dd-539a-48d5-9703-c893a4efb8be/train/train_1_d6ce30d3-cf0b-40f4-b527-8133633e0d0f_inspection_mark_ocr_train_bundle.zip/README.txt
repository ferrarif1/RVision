Vistral railcar inspection dataset bundle
task_type=inspection_mark_ocr
split=train
samples=7
dataset_kind=ocr_text
images/ contains original or cropped images
annotations/records.jsonl contains reviewed labels
