Vistral railcar inspection dataset bundle
task_type=connector_defect_detect
split=train
samples=1
dataset_kind=state_classification
images/ contains original or cropped images
annotations/records.jsonl contains reviewed labels
